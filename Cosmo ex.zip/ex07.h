#ifndef EX07_H
#define EX07_H

#include <iostream>
#include <cmath>

// EX07
template<typename T>
T difference(T a, T b)
{
    return std::abs(b - a);
}


#endif // EX07_H
