#ifndef EX02_H
#define EX02_H

double ponderate(double a, double b, double weight);
double ponderate(double a, double b);

#endif // EX02_H
