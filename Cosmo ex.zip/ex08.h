#ifndef EX08_H
#define EX08_H

// EX08
template<typename TA, typename TB>
double product(TA a, TB b)
{
    return (double)a * b;
}


#endif // EX08_H
